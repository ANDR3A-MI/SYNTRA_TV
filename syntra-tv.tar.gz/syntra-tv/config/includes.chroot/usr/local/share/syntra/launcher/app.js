"use strict";
/* SYNTRA_TV — interfaccia in stile "TV": file di riquadri navigabili
   con frecce, mouse o gamepad. Parla con syntra-shell su 127.0.0.1:7777. */

const ICONS = {
  globe: '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm6.9 6h-2.9a15.7 15.7 0 0 0-1.4-3.6A8 8 0 0 1 18.9 8ZM12 4c.8 1.2 1.5 2.5 1.9 4h-3.8c.4-1.5 1.1-2.8 1.9-4ZM4.3 14a8.2 8.2 0 0 1 0-4h3.3a16.5 16.5 0 0 0 0 4H4.3Zm.8 2h2.9c.3 1.3.8 2.5 1.4 3.6A8 8 0 0 1 5.1 16ZM8 8H5.1a8 8 0 0 1 4.3-3.6C8.8 5.5 8.3 6.7 8 8Zm4 12c-.8-1.2-1.5-2.5-1.9-4h3.8c-.4 1.5-1.1 2.8-1.9 4Zm2.3-6H9.7a14.7 14.7 0 0 1 0-4h4.6a14.7 14.7 0 0 1 0 4Zm.3 5.6c.6-1.1 1.1-2.3 1.4-3.6h2.9a8 8 0 0 1-4.3 3.6Zm1.8-5.6a16.5 16.5 0 0 0 0-4h3.3a8.2 8.2 0 0 1 0 4h-3.3Z"/></svg>',
  mask: '<svg viewBox="0 0 24 24"><path d="M2 9.5C2 8 3 7 4.5 7c2.6 0 4.2 1.3 7.5 1.3S16.9 7 19.5 7C21 7 22 8 22 9.5c0 4-2.6 7.5-6 7.5-2 0-2.8-1.7-4-1.7S10 17 8 17c-3.4 0-6-3.5-6-7.5Zm5 .5c-1.1 0-2 .7-2 1.5S5.9 13 7 13s2-.7 2-1.5S8.1 10 7 10Zm10 0c-1.1 0-2 .7-2 1.5s.9 1.5 2 1.5 2-.7 2-1.5-.9-1.5-2-1.5Z"/></svg>',
  wifi: '<svg viewBox="0 0 24 24"><path d="M12 18.5a1.8 1.8 0 1 1 0 3.6 1.8 1.8 0 0 1 0-3.6ZM12 13c2 0 3.8.8 5.1 2.1l-1.6 1.6A5 5 0 0 0 12 15.2a5 5 0 0 0-3.5 1.5l-1.6-1.6A7.2 7.2 0 0 1 12 13Zm0-4.5c3.3 0 6.3 1.3 8.5 3.5l-1.6 1.6A9.7 9.7 0 0 0 12 10.7c-2.7 0-5.1 1.1-6.9 2.9L3.5 12A12 12 0 0 1 12 8.5ZM12 4c4.6 0 8.7 1.8 11.8 4.8l-1.6 1.6A14.3 14.3 0 0 0 12 6.3c-4 0-7.6 1.6-10.2 4.1L.2 8.8A16.5 16.5 0 0 1 12 4Z"/></svg>',
  wifiOff: '<svg viewBox="0 0 24 24"><path d="m3.3 2 18.7 18.7-1.4 1.4-6.4-6.4A5 5 0 0 0 8.5 16.7l-1.6-1.6a7.2 7.2 0 0 1 4.6-2.1L9.2 10.8a9.7 9.7 0 0 0-4.1 2.8L3.5 12a12 12 0 0 1 3.9-2.9L5 6.7a14 14 0 0 0-3.2 3.7L.2 8.8a16.7 16.7 0 0 1 3.1-3.7L1.9 3.4 3.3 2ZM12 18.5a1.8 1.8 0 1 1 0 3.6 1.8 1.8 0 0 1 0-3.6Zm0-14.5c4.6 0 8.7 1.8 11.8 4.8l-1.6 1.6A14.3 14.3 0 0 0 9.8 6.5L8 4.6c1.3-.4 2.6-.6 4-.6Z"/></svg>',
  power: '<svg viewBox="0 0 24 24"><path d="M11 2h2v10h-2zM6.3 5.2l1.4 1.4a7 7 0 1 0 8.6 0l1.4-1.4A9 9 0 1 1 6.3 5.2Z"/></svg>',
  reboot: '<svg viewBox="0 0 24 24"><path d="M12 4a8 8 0 0 1 7.7 6h-2.1A6 6 0 1 0 18 14h2a8 8 0 1 1-8-10Zm4 0h6v6l-6-6Z"/></svg>',
  lock: '<svg viewBox="0 0 24 24"><path d="M7 10V7a5 5 0 0 1 10 0v3h1.5c.8 0 1.5.7 1.5 1.5v9c0 .8-.7 1.5-1.5 1.5h-13C4.7 22 4 21.3 4 20.5v-9c0-.8.7-1.5 1.5-1.5H7Zm2 0h6V7a3 3 0 0 0-6 0v3Z"/></svg>',
  refresh: '<svg viewBox="0 0 24 24"><path d="M12 4a8 8 0 0 1 7.7 6h-2.1A6 6 0 1 0 18 14h2a8 8 0 1 1-8-10Zm4 0h6v6l-6-6Z"/></svg>',
  unlink: '<svg viewBox="0 0 24 24"><path d="M6 11h12v2H6z"/></svg>',
};

const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/* ---------- Comunicazione col sistema (con modalità demo per l'anteprima) ---------- */
let DEMO = location.protocol === "file:" || location.search.includes("demo");
const demo = {
  status: { enabled: true, ssid: "Casa-Fibra" },
  networks: [
    { ssid: "Casa-Fibra", signal: 82, secure: true, active: true },
    { ssid: "TIM-29384756", signal: 64, secure: true, active: false },
    { ssid: "Vodafone-A1B2", signal: 41, secure: true, active: false },
    { ssid: "Ospiti", signal: 30, secure: false, active: false },
  ],
};
async function api(path, body) {
  if (DEMO) return demoApi(path, body);
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Syntra": "1" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  const data = await r.json().catch(() => ({}));
  if (!r.ok || data.error) throw new Error(data.error || "Errore " + r.status);
  return data;
}
async function demoApi(path, body) {
  await new Promise((r) => setTimeout(r, 350));
  if (path === "/api/wifi/status") return demo.status;
  if (path === "/api/wifi/list") return { networks: demo.networks };
  if (path === "/api/wifi/connect") {
    if (body.password === "sbagliata") throw new Error("Password errata o mancante");
    demo.networks.forEach((n) => (n.active = n.ssid === body.ssid));
    demo.status.ssid = body.ssid;
    return { ok: true };
  }
  if (path === "/api/wifi/disconnect") { demo.status.ssid = null; demo.networks.forEach((n) => (n.active = false)); return { ok: true }; }
  if (path === "/api/wifi/radio") { demo.status.enabled = body.on; if (!body.on) demo.status.ssid = null; return { ok: true }; }
  toast("Anteprima: qui si aprirebbe " + (body && (body.id || body.action)));
  return { ok: true };
}

/* ---------- Stato ---------- */
let rows = [];
const pos = { r: 0, c: 0 };
let panel = null; // { items: [], idx, onBack }

function toast(text) {
  const t = $("#toast");
  t.textContent = text;
  t.classList.add("show");
  clearTimeout(toast.t);
  toast.t = setTimeout(() => t.classList.remove("show"), 2600);
}

/* ---------- Schermata principale ---------- */
function tileHTML(it, r, c) {
  const art = it.icon ? ICONS[it.icon] : esc(it.letter || it.name[0]);
  return `<button class="tile" data-r="${r}" data-c="${c}" tabindex="-1"
      style="--c1:${it.colors[0]};--c2:${it.colors[1]}">
      <img class="mark" src="logo.png" alt="">
      <span class="art">${art}</span>
      <span class="label">${esc(it.name)}</span></button>`;
}

function render() {
  $("#rows").innerHTML = rows.map((row, r) => `
    <section class="row"><h2>${esc(row.title)}</h2>
      <div class="track">${row.items.map((it, c) => tileHTML(it, r, c)).join("")}</div>
    </section>`).join("");
  $("#nav").innerHTML = ["Home", ...rows.map((r) => r.title)].map((t, i) => `<span data-i="${i}">${esc(t)}</span>`).join("");
  document.querySelectorAll(".tile").forEach((el) => {
    el.addEventListener("mouseenter", () => { if (!panel) focusTile(+el.dataset.r, +el.dataset.c); });
    el.addEventListener("click", () => { focusTile(+el.dataset.r, +el.dataset.c); activate(); });
  });
  focusTile(0, 0);
}

function tileEl(r, c) { return document.querySelector(`.tile[data-r="${r}"][data-c="${c}"]`); }
function current() { return rows[pos.r].items[pos.c]; }

function focusTile(r, c) {
  r = Math.max(0, Math.min(rows.length - 1, r));
  c = Math.max(0, Math.min(rows[r].items.length - 1, c));
  const prev = tileEl(pos.r, pos.c);
  if (prev) prev.classList.remove("focus");
  pos.r = r; pos.c = c;
  const el = tileEl(r, c);
  el.classList.add("focus");
  el.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" });
  // la pagina scorre in verticale come su una TV: il banner resta visibile per la prima fila
  window.scrollTo({ top: r === 0 ? 0 : el.closest(".row").offsetTop - window.innerHeight * 0.32, behavior: "smooth" });
  updateHero();
  document.querySelectorAll("#nav span").forEach((s) => s.classList.toggle("on", +s.dataset.i === r + 1));
}

function updateHero() {
  const it = current();
  $("#hero-title").textContent = it.name;
  $("#hero-desc").textContent = it.desc || "";
  $("#hero-tag").textContent = (it.tag || "SYNTRA_TV").toUpperCase();
  $("#hero-art").style.background =
    `radial-gradient(ellipse at 74% 42%, ${it.colors[0]}55 0%, ${it.colors[1]}88 32%, #121315 62%, #0b0b0c 100%)`;
  const hero = $("#hero");
  hero.classList.remove("pulse"); void hero.offsetWidth; hero.classList.add("pulse");
}

async function activate() {
  const it = current();
  const el = tileEl(pos.r, pos.c);
  el.classList.add("pressed");
  setTimeout(() => el.classList.remove("pressed"), 160);
  if (it.action === "wifi") return openWifi();
  if (it.action === "poweroff" || it.action === "reboot") return confirmPower(it.action);
  try {
    await api("/api/launch", { id: it.id });
    if (!DEMO) toast("Apertura di " + it.name + "…");
  } catch (e) { toast(e.message); }
}
$("#hero-open").addEventListener("click", activate);

/* ---------- Pannelli ---------- */
function openPanel(html, onBack) {
  $("#panel").innerHTML = html;
  $("#overlay").classList.remove("hidden");
  const items = [...$("#panel").querySelectorAll("[data-f]")];
  panel = { items, idx: 0, onBack: onBack || closePanel };
  items.forEach((el, i) => {
    el.addEventListener("mouseenter", () => panelFocus(i));
    if (el.tagName !== "INPUT") el.addEventListener("click", () => { panelFocus(i); el.dispatchEvent(new CustomEvent("activate")); });
  });
  panelFocus(0);
  return items;
}
function panelFocus(i) {
  if (!panel || !panel.items.length) return;
  panel.idx = (i + panel.items.length) % panel.items.length;
  panel.items.forEach((el, j) => el.classList.toggle("focus", j === panel.idx));
  const el = panel.items[panel.idx];
  if (el.tagName === "INPUT") el.focus(); else { document.activeElement.blur(); el.scrollIntoView({ block: "nearest" }); }
}
function closePanel() {
  panel = null;
  $("#overlay").classList.add("hidden");
  $("#panel").innerHTML = "";
}
function head(title, extra = "") {
  return `<header><img src="logo.png" alt=""><h3>${esc(title)}</h3><small>${extra}</small></header>`;
}
function loading(title, text) {
  openPanel(`${head(title)}<div class="msg" style="display:flex;gap:14px;align-items:center"><div class="spinner"></div>${esc(text)}</div><div style="height:12px"></div>`);
}

function bars(signal) {
  const n = signal > 75 ? 4 : signal > 50 ? 3 : signal > 25 ? 2 : 1;
  return `<span class="bars">${[1, 2, 3, 4].map((i) => `<i class="${i <= n ? "on" : ""}"></i>`).join("")}</span>`;
}

/* ---------- Wi-Fi ---------- */
async function openWifi() {
  loading("Wi-Fi", "Ricerca delle reti…");
  let status, networks = [];
  try {
    status = await api("/api/wifi/status");
    if (status.enabled) networks = (await api("/api/wifi/list")).networks;
  } catch (e) {
    return openPanel(`${head("Wi-Fi")}<div class="msg">${esc(e.message)}</div>
      <div class="choices"><button class="item" data-f id="b-close">Chiudi</button></div>`) && bindAct("#b-close", closePanel);
  }
  if (!panel) return; // chiuso nel frattempo
  const rowsHTML = [
    `<button class="item" data-f id="w-radio"><span class="ico">${status.enabled ? ICONS.wifi : ICONS.wifiOff}</span>Wi-Fi
      <span class="sub">${status.enabled ? "Attivo · premi per spegnere" : "Spento · premi per accendere"}</span></button>`,
    status.enabled ? `<div class="sep"></div>` : "",
    ...networks.map((n, i) => `<button class="item" data-f data-net="${i}">
      <span class="ico">${n.secure ? ICONS.lock : ICONS.wifi}</span>${esc(n.ssid)}
      <span class="sub">${n.active ? '<span class="badge">CONNESSO</span>' : ""}${bars(n.signal)}</span></button>`),
    status.enabled && !networks.length ? `<div class="msg">Nessuna rete trovata.</div>` : "",
    status.enabled ? `<div class="sep"></div><button class="item" data-f id="w-scan"><span class="ico">${ICONS.refresh}</span>Cerca di nuovo</button>` : "",
    status.ssid ? `<button class="item" data-f id="w-off"><span class="ico">${ICONS.unlink}</span>Disconnetti da ${esc(status.ssid)}</button>` : "",
  ].join("");
  openPanel(`${head("Wi-Fi", status.ssid ? "Connesso a " + esc(status.ssid) : "Non connesso")}<div class="list">${rowsHTML}</div>`);
  bindAct("#w-radio", async () => { await safe(() => api("/api/wifi/radio", { on: !status.enabled })); refreshNet(); openWifi(); });
  bindAct("#w-scan", openWifi);
  bindAct("#w-off", async () => { await safe(() => api("/api/wifi/disconnect", {})); refreshNet(); openWifi(); });
  document.querySelectorAll("[data-net]").forEach((el) => el.addEventListener("activate", () => {
    const n = networks[+el.dataset.net];
    if (n.active) return toast("Sei già connesso a " + n.ssid);
    if (n.secure) askPassword(n.ssid); else connect(n.ssid, "");
  }));
  // parte dalla prima rete, non dall'interruttore
  if (networks.length) panelFocus(1);
}

function askPassword(ssid, error) {
  const items = openPanel(`${head(ssid, "Rete protetta")}
    ${error ? `<div class="msg" style="color:#ff8a8a">${esc(error)}</div>` : ""}
    <div class="pw"><label>Password</label><input data-f type="password" id="pw" autocomplete="off" spellcheck="false"></div>
    <div class="choices"><button class="item" data-f id="pw-ok">Connetti</button><button class="item" data-f id="pw-no">Annulla</button></div>`,
    openWifi);
  const go = () => connect(ssid, $("#pw").value);
  $("#pw").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); go(); } });
  bindAct("#pw-ok", go);
  bindAct("#pw-no", openWifi);
  return items;
}

async function connect(ssid, password) {
  loading(ssid, "Connessione in corso…");
  try {
    await api("/api/wifi/connect", { ssid, password });
    closePanel();
    toast("Connesso a " + ssid);
    refreshNet();
  } catch (e) {
    askPassword(ssid, e.message);
  }
}

/* ---------- Spegni / Riavvia ---------- */
function confirmPower(action) {
  const [word, verb] = action === "poweroff" ? ["Spegnere", "Spegni"] : ["Riavviare", "Riavvia"];
  openPanel(`${head(word + " il computer?")}<div class="msg">Le finestre aperte di Brave verranno chiuse.</div>
    <div class="choices"><button class="item" data-f id="p-no">Annulla</button><button class="item" data-f id="p-yes">${verb}</button></div>`);
  bindAct("#p-no", closePanel);
  bindAct("#p-yes", async () => { closePanel(); toast(action === "poweroff" ? "Spegnimento…" : "Riavvio…"); await safe(() => api("/api/power", { action })); });
}

function bindAct(sel, fn) { const el = $(sel); if (el) el.addEventListener("activate", fn); return true; }
async function safe(fn) { try { return await fn(); } catch (e) { toast(e.message); } }

/* ---------- Barra di stato ---------- */
async function refreshNet() {
  const el = $("#net");
  try {
    const s = await api("/api/wifi/status");
    el.className = "net" + (s.ssid ? " ok" : "");
    el.innerHTML = (s.enabled ? ICONS.wifi : ICONS.wifiOff) + `<span>${esc(s.ssid || (s.enabled ? "Non connesso" : "Wi-Fi spento"))}</span>`;
  } catch { el.innerHTML = ICONS.wifiOff + "<span>—</span>"; }
}
function tick() {
  const d = new Date();
  $("#clock").textContent = d.toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
}

/* ---------- Comandi: tastiera ---------- */
function press(key) {
  if (panel) {
    const el = panel.items[panel.idx];
    const inChoices = el && el.parentElement.classList.contains("choices");
    if (key === "up") panelFocus(panel.idx - 1);
    else if (key === "down") panelFocus(panel.idx + 1);
    else if (key === "left" && inChoices) panelFocus(panel.idx - 1);
    else if (key === "right" && inChoices) panelFocus(panel.idx + 1);
    else if (key === "ok" && el && el.tagName !== "INPUT") el.dispatchEvent(new CustomEvent("activate"));
    else if (key === "ok" && el && el.tagName === "INPUT") $("#pw-ok").dispatchEvent(new CustomEvent("activate"));
    else if (key === "back") panel.onBack();
    return;
  }
  if (key === "left") focusTile(pos.r, pos.c - 1);
  else if (key === "right") focusTile(pos.r, pos.c + 1);
  else if (key === "up") focusTile(pos.r - 1, pos.c);
  else if (key === "down") focusTile(pos.r + 1, pos.c);
  else if (key === "ok") activate();
}
const KEYS = { ArrowLeft: "left", ArrowRight: "right", ArrowUp: "up", ArrowDown: "down", Enter: "ok", " ": "ok", Escape: "back", Backspace: "back" };
document.addEventListener("keydown", (e) => {
  const k = KEYS[e.key];
  if (!k) return;
  const typing = document.activeElement && document.activeElement.tagName === "INPUT";
  if (typing && (k === "left" || k === "right" || e.key === " " || e.key === "Backspace")) return; // lascia scrivere
  e.preventDefault();
  press(k);
});
document.addEventListener("contextmenu", (e) => e.preventDefault());

/* ---------- Comandi: gamepad (A = apri, B = indietro) ---------- */
const pad = { held: {}, next: {} };
function pollPad(t) {
  const gp = [...(navigator.getGamepads ? navigator.getGamepads() : [])].find(Boolean);
  if (gp) {
    const ax = gp.axes[0] || 0, ay = gp.axes[1] || 0, b = (i) => gp.buttons[i] && gp.buttons[i].pressed;
    const state = {
      left: b(14) || ax < -0.6, right: b(15) || ax > 0.6, up: b(12) || ay < -0.6, down: b(13) || ay > 0.6,
      ok: b(0), back: b(1),
    };
    for (const k in state) {
      if (state[k] && (!pad.held[k] || t > pad.next[k])) {
        press(k);
        pad.next[k] = t + (pad.held[k] ? 110 : 380); // ripetizione come su una TV
      }
      pad.held[k] = state[k];
    }
  }
  requestAnimationFrame(pollPad);
}

/* ---------- Avvio ---------- */
(async function start() {
  try {
    rows = (await (await fetch("apps.json")).json()).rows;
  } catch {
    DEMO = true;
    rows = window.SYNTRA_APPS || [];
  }
  render();
  tick(); setInterval(tick, 5000);
  refreshNet(); setInterval(refreshNet, 10000);
  requestAnimationFrame(pollPad);
})();
