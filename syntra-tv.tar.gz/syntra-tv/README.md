# SYNTRA_TV

Sistema operativo minimale: **Brave + impostazioni Wi-Fi**, con un'interfaccia a
schermo intero in stile TV (file di riquadri, banner grande, navigazione con
frecce, mouse o gamepad). Pensato per **HP 255 G6** (AMD E2-9000e, Radeon R2,
Wi-Fi Intel 3168NGW, 4 GB RAM, SSD).

Base: Debian 13 "trixie", 64 bit, Xorg + Openbox, NetworkManager.

## Come è fatto

```
accensione → accesso automatico (utente "syntra") → Openbox
   ├─ syntra-shell     servizio locale su 127.0.0.1:7777 (Python, nessuna dipendenza)
   │                   avvia le app, gestisce il Wi-Fi con nmcli, spegne/riavvia
   └─ SYNTRA_TV      Brave in modalità kiosk che mostra l'interfaccia
                       (si riapre da sola se viene chiusa)
```

| Tasto | Azione |
|---|---|
| Frecce / levetta gamepad | Muoversi tra i riquadri |
| Invio / A | Apri |
| Esc / B | Indietro |
| Tasto Windows | Torna a SYNTRA_TV da qualsiasi app |
| Alt+Tab | Passa tra le finestre |
| Tasti Fn volume/luminosità | Funzionano |

## Personalizzare

- **Riquadri:** `config/includes.chroot/usr/local/share/syntra/launcher/apps.json`
  (nome, descrizione, colori, comando). Il comando lo legge solo il servizio
  locale: la pagina può chiedere di aprire solo le app elencate lì.
- **Aspetto:** `style.css` nella stessa cartella. Il logo è `logo.png`.
- **Anteprima sul PC:** apri `index.html` nel browser (modalità demo, con reti
  Wi-Fi finte; prova la password `sbagliata` per vedere l'errore).

## Costruire la ISO

Serve Debian 13 (o una VM Debian 13) con circa 10 GB liberi e internet:

```
sudo apt install live-build
cd syntra-tv
sudo lb config
sudo lb build
```

In alternativa: carica la cartella su GitHub e lancia l'azione
**Build SYNTRA_TV ISO**; la ISO compare tra gli artefatti.

Scrivi la ISO su chiavetta (balenaEtcher, Rufus in modalità DD, oppure
`sudo dd if=live-image-amd64.hybrid.iso of=/dev/sdX bs=4M status=progress`).

## Installare sull'HP 255 G6

1. Accendi tenendo premuto **Esc**, poi **F9** e scegli la chiavetta.
2. Prova prima la modalità live: Wi-Fi, audio, tasti.
3. Dal menu di avvio scegli **Install** e indica il disco **sda (223 GB)**.
   **Non scegliere sdb (la chiavetta).**
4. Quando l'installer chiede il nome utente, scrivi **`syntra`**: l'accesso
   automatico usa quel nome.

## Stato

Configurazione scritta e interfaccia provata in anteprima; **la ISO non è
ancora stata costruita né provata sul portatile**. Da verificare alla prima
build: installazione di Brave dal repository, accesso automatico, Wi-Fi Intel
3168 e audio.
